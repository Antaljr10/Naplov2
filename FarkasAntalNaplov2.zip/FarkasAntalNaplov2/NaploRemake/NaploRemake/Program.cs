﻿using Google.Protobuf.WellKnownTypes;
using MySql.Data.MySqlClient;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Tls;
using System;
using System.ComponentModel.Design;
using System.Data;
using System.Drawing;
using System.Security.Cryptography;
using System.Text;
using System.Xml;

namespace reg_bej
{
    internal class Program
    {
        public struct nap
        {
            public string mondatok;

            public string hangulat, cim, datum;


        }
        static void Main(string[] args)
        {
            bool megtalal = false;
            string felhnev = "";

            string kapcsString = $@"server=localhost;userid=root;password=;database=naplo";
            MySqlConnection kapcs = kapcsolat(kapcsString);
            int valasz = 0;
            while (valasz != 2)
            {
                valasz = nyilas(ref valasz, 3);
                if (valasz == 0)
                    regisztralas(kapcs);
                else if (valasz == 1)
                {
                    bejelentkezes(kapcs, ref megtalal, ref felhnev);
                    if (megtalal == true)
                        valasz = 2;

                }
            }

            int valasz2 = 0;


            if (megtalal == true)
            {
                while (valasz2 != 4)
                {
                    valasz2 = nyilas(ref valasz2, 4);

                    if (valasz2 == 0)
                    {

                        nap ma = ujbejegyzes(kapcs, felhnev);

                        mentes(kapcs, felhnev, ma);
                        tisztitas(kapcs);


                    }
                    if (valasz2 == 1)
                    {

                        nap ma2 = szerkbejegyzes(kapcs, felhnev);

                        feluliras(kapcs, felhnev, ma2);


                    }
                    if (valasz2 == 2)
                    {
                        szuro(kapcs, felhnev);
                    }
                }
            }
            static void hangulatgrafikon(MySqlConnection kapcs, string felhnev)
            {
                kapcs.Open();
                string sqlUtasitas = $"SELECT * FROM bejegyzesek WHERE felh = '{felhnev}';";
                MySqlCommand sqlParancs = new MySqlCommand(sqlUtasitas, kapcs);
                sqlParancs.Prepare();
                MySqlDataReader mySqlDataReader = sqlParancs.ExecuteReader();

                int fort = 0;
                int csap = 0;
                int morc = 0;
                int okes = 0;
                int bold = 0;
                int nagysz = 0;


                while (mySqlDataReader.Read())
                {
                    if (mySqlDataReader.GetString(4) == "Csapnivalo")
                        csap++;
                    else if (mySqlDataReader.GetString(4) == "Förtelmes")
                        fort++;
                    else if (mySqlDataReader.GetString(4) == "Förtelmes")
                        morc++;
                    else if (mySqlDataReader.GetString(4) == "Förtelmes")
                        okes++;
                    else if (mySqlDataReader.GetString(4) == "Förtelmes")
                        bold++;
                    else if (mySqlDataReader.GetString(4) == "Förtelmes")
                        nagysz++;
                }

                Console.WriteLine($"{"Förtelmes",-10}");
            }
            static void tisztitas(MySqlConnection kapcs)
            {
                kapcs.Open();
                string sqlUtasitas = $"DELETE FROM bejegyzesek WHERE cim = '' AND szoveg = '';";
                MySqlCommand sqlParancs = new MySqlCommand(sqlUtasitas, kapcs);
                sqlParancs.Prepare();
                MySqlDataReader mySqlDataReader = sqlParancs.ExecuteReader();
                kapcs.Close();
            }
            static void szuro(MySqlConnection kapcs, string felhnev)
            {
                Console.Clear();
                Console.WriteLine("Mely bejegyzéseket szeretné látni?");

                string[] menupontok = new string[] { "Összes", "Csapnivalo", "Förtelmes", "Morcos", "Okés", "Boldog", "Nagyszerű" };

                for (int i = 0; i < menupontok.Length; i++)
                {
                    Console.WriteLine($"--{i}. {menupontok[i]}");
                }

                int vjo = helyesinpt(6);

                szurtbejegyzesek(kapcs, felhnev, menupontok[vjo]);

            }
            static void szurtbejegyzesek(MySqlConnection kapcs, string felhnev, string feltetel)
            {
                Console.Clear();
                Console.Beep();
                if (kapcs.State != ConnectionState.Open)
                {
                    kapcs.Open();
                }

                string sqlUtasitas;
                if (feltetel != "Összes")
                {
                    sqlUtasitas = $"SELECT * FROM bejegyzesek WHERE felh = '{felhnev}' AND hangulat = '{feltetel}';";
                }
                else
                {
                    sqlUtasitas = $"SELECT * FROM bejegyzesek WHERE felh = '{felhnev}';";
                }

                MySqlCommand sqlParancs = new MySqlCommand(sqlUtasitas, kapcs);
                sqlParancs.Prepare();
                MySqlDataReader mySqlDataReader = sqlParancs.ExecuteReader();

                bool hasRows = mySqlDataReader.HasRows;
                if (feltetel == "Összes")
                {
                    hasRows = true; // Consider the case as if there are rows even if there aren't any
                }

                if (hasRows)
                {
                    while (mySqlDataReader.Read())
                    {


                        Console.WriteLine($"");


                        string cim = mySqlDataReader.GetString(1);
                        string keszult = mySqlDataReader.GetString(3);
                        string tartalom = mySqlDataReader.GetString(2);
                        string hangulat = mySqlDataReader.GetString(4);


                        Console.WriteLine($"Bejegyzés címe: {cim}");


                        Console.WriteLine($"Bejegyzés Készült: {keszult}");


                        Console.WriteLine($"Bejegyzés Tartalma: {tartalom}");


                        Console.WriteLine($"Hangulat: {hangulat}");

                        Console.WriteLine($"");
                        Console.ResetColor();
                    }
                }
                else
                {
                    Console.WriteLine("Nincs bejegyzés.");
                }

                mySqlDataReader.Close();
                kapcs.Close();
                Console.ReadLine();
            }


            static nap szerkbejegyzes(MySqlConnection kapcs, string felhnev)
            {

                if (kapcs.State != ConnectionState.Open)
                {
                    kapcs.Open();
                }

                Console.Clear();
                string sqlUtasitas = $"SELECT * FROM bejegyzesek WHERE felh = '{felhnev}' AND datum = '{DateTime.Now.ToString("yyyy/M/d")}' ;";

                MySqlCommand sqlParancs = new MySqlCommand(sqlUtasitas, kapcs);

                sqlParancs.Prepare();
                MySqlDataReader mySqlDataReader = sqlParancs.ExecuteReader();
                if (mySqlDataReader.HasRows)
                {
                    Console.WriteLine("\r\n   _____             _                 _    __      \r\n  / ____|           | |               | |  /_/      \r\n | (___ _______ _ __| | _____  ___ ___| |_ ___  ___ \r\n  \\___ \\_  / _ \\ '__| |/ / _ \\/ __|_  / __/ _ \\/ __|\r\n  ____) / /  __/ |  |   <  __/\\__ \\/ /| ||  __/\\__ \\\r\n |_____/___\\___|_|  |_|\\_\\___||___/___|\\__\\___||___/\r\n                                                    \r\n                                                    \r\n");
                    mySqlDataReader.Read();
                    nap ma;
                    ma.cim = mySqlDataReader.GetString(1);
                    ma.mondatok = mySqlDataReader.GetString(2);
                    ma.datum = mySqlDataReader.GetString(3);
                    ma.hangulat = mySqlDataReader.GetString(4);

                    kapcs.Close();
                    Console.WriteLine($"\n  {DateTime.Now.ToString("yyyy/M/d")}");

                    Console.WriteLine($"\n  Bejegyzés címe:");
                    Console.SetCursorPosition(17, 13);
                    ma.cim = inputedit(ma.cim);
                    Console.WriteLine("");
                    Console.WriteLine($"\n  Bejegyzés tartalma:");
                    Console.SetCursorPosition(22, 15);
                    ma.mondatok = inputedit(ma.mondatok);
                    Console.WriteLine($"\n  Milyen a hangulatod:");


                    string[] menupontok = new string[] { " Csapnivalo ", " Förtelmes ", " Morcos ", " Okés ", " Boldog ", " Nagyszerű" };

                    for (int i = 0; i < menupontok.Length; i++)
                    {
                        Console.WriteLine($"--{i}. {menupontok[i]}");
                    }

                    int vjo = helyesinpt(5);



                    if (vjo == 0)
                    {
                        ma.hangulat = "Csapnivalo";
                        return ma;
                    }
                    else if (vjo == 1)
                    {
                        ma.hangulat = "Förtelmes";
                        return ma;
                    }
                    else if (vjo == 2)
                    {
                        ma.hangulat = "Morcos";
                        return ma;
                    }
                    else if (vjo == 3)
                    {
                        ma.hangulat = "Okés";
                        return ma;
                    }
                    else if (vjo == 4)
                    {
                        ma.hangulat = "Boldog";
                        return ma;
                    }
                    else if (vjo == 5)
                    {
                        ma.hangulat = "Nagyszerű";
                        return ma;
                    }

                    return ma;
                }
                kapcs.Close();
                nap ma2 = ujbejegyzes(kapcs, felhnev);
                mentes(kapcs, felhnev, ma2);

                return ma2;


            }
            static nap ujbejegyzes(MySqlConnection kapcs, string felhnev)
            {

                if (kapcs.State != ConnectionState.Open)
                {
                    kapcs.Open();
                }

                Console.Clear();
                string sqlUtasitas = $"SELECT datum FROM bejegyzesek WHERE felh = '{felhnev}' AND datum = '{DateTime.Now.ToString("yyyy/M/d")}' ;";

                MySqlCommand sqlParancs = new MySqlCommand(sqlUtasitas, kapcs);

                sqlParancs.Prepare();
                MySqlDataReader mySqlDataReader = sqlParancs.ExecuteReader();

                nap ma;
                ma.hangulat = "";
                ma.cim = "";
                ma.mondatok = "";
                ma.datum = "";

                bool benv = false;

                while (mySqlDataReader.Read())
                {
                    if (mySqlDataReader.GetString(0) == DateTime.Now.ToString("yyyy/M/d")) ;
                    benv = true;
                }
                mySqlDataReader.Close();

                if (benv == true)
                {
                    Console.WriteLine("A mai nap már készült bejegyzés.\nHa szeretné modosítani válassza a bejegyzés szerkesztése menüpontot!");
                }

                else if (benv == false)
                {


                    Console.WriteLine(" __  __       __        ______     ______       __     ______     ______     __  __     ______     ______     ______    \r\n/\\ \\/\\ \\     /\\ \\      /\\  == \\   /\\  ___\\     /\\ \\   /\\  ___\\   /\\  ___\\   /\\ \\_\\ \\   /\\___  \\   /\\  ___\\   /\\  ___\\   \r\n\\ \\ \\_\\ \\   _\\_\\ \\     \\ \\  __<   \\ \\  __\\    _\\_\\ \\  \\ \\  __\\   \\ \\ \\__ \\  \\ \\____ \\  \\/_/  /__  \\ \\  __\\   \\ \\___  \\  \r\n \\ \\_____\\ /\\_____\\     \\ \\_____\\  \\ \\_____\\ /\\_____\\  \\ \\_____\\  \\ \\_____\\  \\/\\_____\\   /\\_____\\  \\ \\_____\\  \\/\\_____\\ \r\n  \\/_____/ \\/_____/      \\/_____/   \\/_____/ \\/_____/   \\/_____/   \\/_____/   \\/_____/   \\/_____/   \\/_____/   \\/_____/ \r\n                                                                                                                        ");
                    Console.WriteLine($"\n  {DateTime.Now.ToString("yyyy/M/d")}");
                    ma.datum = DateTime.Now.ToString("yyyy/M/d");
                    Console.WriteLine($"\n  Bejegyzés címe:");
                    Console.SetCursorPosition(17, 9);
                    ma.cim = Console.ReadLine();
                    Console.WriteLine($"\n  Bejegyzés tartalma:");
                    Console.SetCursorPosition(22, 11);
                    ma.mondatok = Console.ReadLine();
                    Console.WriteLine($"\n  Milyen a hangulatod:");


                    string[] menupontok = new string[] { " Csapnivalo ", " Förtelmes ", " Morcos ", " Okés ", " Boldog ", " Nagyszerű" };

                    for (int i = 0; i < menupontok.Length; i++)
                    {
                        Console.WriteLine($"--{i}. {menupontok[i]}");
                    }

                    int vjo = helyesinpt(5);



                    if (vjo == 0)
                    {
                        ma.hangulat = "Csapnivalo";
                        return ma;
                    }
                    else if (vjo == 1)
                    {
                        ma.hangulat = "Förtelmes";
                        return ma;
                    }
                    else if (vjo == 2)
                    {
                        ma.hangulat = "Morcos";
                        return ma;
                    }
                    else if (vjo == 3)
                    {
                        ma.hangulat = "Okés";
                        return ma;
                    }
                    else if (vjo == 4)
                    {
                        ma.hangulat = "Boldog";
                        return ma;
                    }
                    else if (vjo == 5)
                    {
                        ma.hangulat = "Nagyszerű";
                        return ma;
                    }




                }

                kapcs.Close();
                return ma;


            }
            static void mentes(MySqlConnection kapcs, string felhnev, nap ma)
            {

                if (kapcs.State != ConnectionState.Open)
                {
                    kapcs.Open();
                }
                string sqlUtasitas = $"INSERT INTO bejegyzesek(cim,szoveg,datum,hangulat,felh) VALUES('{ma.cim}','{ma.mondatok}','{ma.datum}','{ma.hangulat}','{felhnev}');";

                MySqlCommand sqlParancs = new MySqlCommand(sqlUtasitas, kapcs);

                sqlParancs.Prepare();

                sqlParancs.ExecuteNonQuery();
                kapcs.Close();


            }
            static void feluliras(MySqlConnection kapcs, string felhnev, nap ma)
            {
                if (kapcs.State != ConnectionState.Open)
                {
                    kapcs.Open();
                }


                string sqlUtasitas = $"UPDATE bejegyzesek SET cim = '{ma.cim}' , szoveg = '{ma.mondatok}' , datum = '{ma.datum}', hangulat ='{ma.hangulat}' ,  felh ='{felhnev}' WHERE datum = '{ma.datum}' AND felh = '{felhnev}'";



                MySqlCommand sqlParancs = new MySqlCommand(sqlUtasitas, kapcs);

                sqlParancs.Prepare();

                sqlParancs.ExecuteNonQuery();
                kapcs.Close();


            }
            static int helyesinpt(int max)
            {
                int num;
                while (true)
                {
                    Console.WriteLine("Hangulatod:");
                    Console.SetCursorPosition(12, Console.GetCursorPosition().Top - 1);
                    string input = Console.ReadLine();

                    if (int.TryParse(input, out num))
                    {
                        if (num >= 0 && num <= max)
                            return num;
                        else
                            Console.WriteLine($"A szám 0-{max} között legyen.");
                    }
                    else
                        Console.WriteLine("Kérlek SZÁMOT adj meg!");
                }
                return 0;
            }

            static void naplomenu(ref int valasz2)
            {

                int sor = 7;
                Console.ForegroundColor = ConsoleColor.Black;
                Console.BackgroundColor = ConsoleColor.White;
                Console.SetCursorPosition(30, 5); // Az első sor elejére állítja a kurzort
                Console.WriteLine("┌───────────────────────────────────────────────────┐");
                Console.SetCursorPosition(30, 6);
                Console.WriteLine("│                      NAPLO                        │");
                Console.SetCursorPosition(30, 7);
                Console.WriteLine("├───────────────────────────────────────────────────┤");
                string[] menupontok = new string[] { "  1. Új Bejegyzés   ", "  2. Bejegyzés Szerkesztése  ", "  3. Bejegyzések", "  4. Kilépés" };
                for (int i = 0; i < menupontok.Length; i++)
                {
                    string aktualis = menupontok[i];
                    //Kivalasztott menupont kiemelese
                    if (i == valasz2)
                    {
                        Console.SetCursorPosition(30, sor + 1);
                        sor++;
                        Console.BackgroundColor = ConsoleColor.DarkGray;
                        Console.ForegroundColor = ConsoleColor.Black;
                        Console.WriteLine($"│{aktualis,-51}│");

                    }
                    else
                    {
                        Console.SetCursorPosition(30, sor + 1);
                        sor++;
                        Console.BackgroundColor = ConsoleColor.White;
                        Console.ForegroundColor = ConsoleColor.Black;
                        Console.WriteLine($"│{menupontok[i],-51}│");
                    }
                }
                Console.SetCursorPosition(30, sor + 1);
                Console.WriteLine("└───────────────────────────────────────────────────┘");
                Console.ResetColor();
            }


            static int nyilas(ref int index, int menu)
            {
                //Navigalas a menuben
                ConsoleKey kiv;
                do
                {
                    Console.Clear();
                    if (menu == 3)
                    {
                        bejelentkezesmenu(ref index);


                    }
                    else if (menu == 4)
                    {
                        naplomenu(ref index);
                    }


                    //Lenyomott gombok feldolgozása amíg a felhasznalo nem nyom Entert
                    ConsoleKeyInfo consoleKeyInfo = Console.ReadKey(true);
                    kiv = consoleKeyInfo.Key;

                    if (kiv == ConsoleKey.DownArrow & index < menu)
                    {
                        index++;
                    }

                    if (kiv == ConsoleKey.DownArrow & index == menu)
                    {
                        index = 0;
                    }
                    else if (kiv == ConsoleKey.UpArrow & index > 0)
                    {
                        index--;
                    }


                }
                while (kiv != ConsoleKey.Enter);

                return index;
            }
            static void bejelentkezesmenu(ref int valasz)
            {
                int sor = 7;
                Console.ForegroundColor = ConsoleColor.Black;
                Console.BackgroundColor = ConsoleColor.White;
                Console.SetCursorPosition(30, 5); // Az első sor elejére állítja a kurzort
                Console.WriteLine("┌───────────────────────────────────────────────────┐");
                Console.SetCursorPosition(30, 6);
                Console.WriteLine("│            BEJELENTKEZÉS/REGISZTRÁLÁS             │");
                Console.SetCursorPosition(30, 7);
                Console.WriteLine("├───────────────────────────────────────────────────┤");
                string[] menupontok = new string[] { "  1. Regisztrálás   ", "  2. Bejelentkezés  ", "  3. Kilépés        " };
                for (int i = 0; i < menupontok.Length; i++)
                {
                    string aktualis = menupontok[i];
                    //Kivalasztott menupont kiemelese
                    if (i == valasz)
                    {
                        Console.SetCursorPosition(30, sor + 1);
                        sor++;
                        Console.BackgroundColor = ConsoleColor.DarkGray;
                        Console.ForegroundColor = ConsoleColor.Black;
                        Console.WriteLine($"│{aktualis,-51}│");

                    }
                    else
                    {
                        Console.SetCursorPosition(30, sor + 1);
                        sor++;
                        Console.BackgroundColor = ConsoleColor.White;
                        Console.ForegroundColor = ConsoleColor.Black;
                        Console.WriteLine($"│{menupontok[i],-51}│");
                    }
                }
                Console.SetCursorPosition(30, sor + 1);
                Console.WriteLine("└───────────────────────────────────────────────────┘");
                Console.ResetColor();
            }
            static void regisztralas(MySqlConnection kapcs)
            {
                Console.Clear();
                try
                {
                    kapcs.Open();


                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.SetCursorPosition(30, 5); // Az első sor elejére állítja a kurzort
                    Console.WriteLine("┌───────────────────────────────────────────────────┐");
                    Console.SetCursorPosition(30, 6);
                    Console.WriteLine("│                  REGISZTRÁLÁCIO                   │");
                    Console.SetCursorPosition(30, 7);
                    Console.WriteLine("├───────────────────────────────────────────────────┤");
                    Console.SetCursorPosition(30, 8);
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.WriteLine($"│{"Add meg a felhasznalo neved:",-51}│");
                    Console.Write("");
                    Console.SetCursorPosition(60, 8);
                    string felhnev = helyesfelhnev();
                    Console.SetCursorPosition(30, 9);
                    Console.WriteLine($"│{"Add meg a jelszavad:",-51}│");
                    Console.SetCursorPosition(52, 9);
                    string jelsz = jelszo();
                    jelsz = ComputeSHA256(jelsz);
                    Console.SetCursorPosition(30, 10);
                    Console.WriteLine("└───────────────────────────────────────────────────┘");
                    Console.ResetColor();

                    string sqlUtasitas = $"INSERT INTO felhasznalok(nev,jelszo) VALUES('{felhnev}', '{jelsz}');";



                    MySqlCommand sqlParancs = new MySqlCommand(sqlUtasitas, kapcs);


                    sqlParancs.Prepare();
                    sqlParancs.ExecuteNonQuery();

                    kapcs.Close();
                    Console.WriteLine("Sikeres Regisztracio!");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    Console.WriteLine("Foglalt felhasznalonev!");
                    Console.ReadLine();
                    kapcs.Close();
                }
            }
            static string helyesfelhnev()
            {
                string userinpt = Console.ReadLine();
                while (userinpt == "")
                {
                    userinpt = Console.ReadLine();
                }
                return userinpt;
            }
            static void bejelentkezes(MySqlConnection kapcs, ref bool megtalal, ref string felhnev)
            {
                Console.Clear();
                kapcs.Open();


                Console.ForegroundColor = ConsoleColor.Black;
                Console.BackgroundColor = ConsoleColor.White;
                Console.SetCursorPosition(30, 5); // Az első sor elejére állítja a kurzort
                Console.WriteLine("┌───────────────────────────────────────────────────┐");
                Console.SetCursorPosition(30, 6);
                Console.WriteLine("│                  BEJELENTKEZÉS                    │");
                Console.SetCursorPosition(30, 7);
                Console.WriteLine("├───────────────────────────────────────────────────┤");
                Console.SetCursorPosition(30, 8);
                Console.BackgroundColor = ConsoleColor.White;
                Console.ForegroundColor = ConsoleColor.Black;
                Console.WriteLine($"│{"Add meg a felhasznalo neved:",-51}│");
                Console.Write("");
                Console.SetCursorPosition(60, 8);
                felhnev = Console.ReadLine();
                Console.SetCursorPosition(30, 9);
                Console.WriteLine($"│{"Add meg a jelszavad:",-51}│");
                Console.SetCursorPosition(52, 9);
                string jelsz = jelszo();
                jelsz = ComputeSHA256(jelsz);
                Console.SetCursorPosition(30, 10);
                Console.WriteLine("└───────────────────────────────────────────────────┘");
                Console.ResetColor();




                string sqlUtasitas = $"SELECT nev,jelszo FROM felhasznalok;";

                MySqlCommand sqlParancs = new MySqlCommand(sqlUtasitas, kapcs);

                sqlParancs.Prepare();
                MySqlDataReader mySqlDataReader = sqlParancs.ExecuteReader();

                while (mySqlDataReader.Read())
                {

                    if (mySqlDataReader.GetString(0) == felhnev & mySqlDataReader.GetString(1) == jelsz)
                        megtalal = true;

                }
                if (megtalal == true)
                {

                    Console.WriteLine("Sikeres bejelentkezes!");
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Sikertelen Bejelentkezes!");
                }
                Console.ResetColor();


                Console.ReadLine();
                kapcs.Close();
                Console.Clear();
            }

            static string jelszo()
            {
                ConsoleKeyInfo bill;

                string jelszo = "";
                do
                {
                    bill = Console.ReadKey(true);
                    if (bill.Key != ConsoleKey.Enter & bill.Key != ConsoleKey.Backspace)
                    {
                        jelszo += bill.KeyChar;
                        Console.Write("*");
                    }
                    else if (bill.Key == ConsoleKey.Backspace)
                    {
                        jelszo = jelszo.Substring(0, jelszo.Length - 1);
                        Console.Write("\b \b");
                    }
                }
                while (bill.Key != ConsoleKey.Enter);

                return jelszo;
            }
            static string inputedit(string moka)
            {
                ConsoleKeyInfo bill;

                Console.Write(moka);
                do
                {
                    bill = Console.ReadKey(true);
                    if (bill.Key != ConsoleKey.Enter & bill.Key != ConsoleKey.Backspace)
                    {
                        moka += bill.KeyChar;
                        Console.Write(bill.KeyChar);
                    }
                    else if (bill.Key == ConsoleKey.Backspace && moka.Length != 0)
                    {
                        moka = moka.Substring(0, moka.Length - 1);
                        Console.Write("\b \b");
                    }
                }
                while (bill.Key != ConsoleKey.Enter);

                return moka;
            }
            static MySqlConnection kapcsolat(string kapcsString)
            {
                MySqlConnection kapcs = new MySqlConnection(kapcsString);
                return kapcs;
            }

            static string ComputeSHA256(string s)
            {
                using (SHA256 sha256 = SHA256.Create())
                {
                    byte[] hashValue = sha256.ComputeHash(Encoding.UTF8.GetBytes(s));
                    return Convert.ToHexString(hashValue);
                }
            }

        }
    }
}